import{a9 as e}from"./index-DDbD1qKv.js";const s="/purchase-returns";async function r(){return(await e.get(s)).data??[]}async function o(){return(await e.get(`${s}/stats`)).data}async function c(t){return(await e.get(`${s}/returnable/${t}`)).data}async function u(t){return(await e.post(s,t)).data}export{o as a,c as b,u as c,r as g};
//# sourceMappingURL=purchase-returns.service-NklOh_pV.js.map
