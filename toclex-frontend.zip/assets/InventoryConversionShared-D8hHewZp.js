const a={DRAFT:{label:"Borrador",tone:"gray"},PENDING:{label:"Pendiente",tone:"yellow"},APPROVED:{label:"Aprobada",tone:"green"},CANCELLED:{label:"Cancelada",tone:"red"}},o=e=>"$"+Math.round(Number(e||0)).toLocaleString("es-CO");export{a as C,o as f};
//# sourceMappingURL=InventoryConversionShared-D8hHewZp.js.map
